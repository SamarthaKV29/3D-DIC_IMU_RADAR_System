var a00120 =
[
    [ "inv_icm20648_sensor", "a00120.html#gabc6bb26b4752e935d63b954fc4da388a", null ],
    [ "inv_icm20648_set_lowpower_or_highperformance", "a00120.html#gabe7aa6f20ec8b59fa3da2514ac268983", null ]
];