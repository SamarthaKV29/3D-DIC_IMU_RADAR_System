var a00133 =
[
    [ "INV_MAX_SERIAL_READ", "a00133.html#ga3239414549ba4d085a60637e40417cd9", null ],
    [ "INV_MAX_SERIAL_WRITE", "a00133.html#ga1a2ff08175c9aad83693b34f866960bc", null ],
    [ "inv_icm20948_read_mems", "a00133.html#ga09fda243ff8c86c02f199c5cd8c7ab16", null ],
    [ "inv_icm20948_read_mems_reg", "a00133.html#gad3bc965b7521830f01ebed806de24063", null ],
    [ "inv_icm20948_write_mems", "a00133.html#gab183fa6c8f62cc66edcfcebaea1eaaf2", null ],
    [ "inv_icm20948_write_mems_reg", "a00133.html#ga868e9ce97909f5faa0b51ea1203de421", null ],
    [ "inv_icm20948_write_single_mems_reg", "a00133.html#ga02a39987b6b81341be291d0a849b33dc", null ],
    [ "inv_icm20948_write_single_mems_reg_core", "a00133.html#ga9bedbe765b506fdcd02bc809f67aa99c", null ]
];