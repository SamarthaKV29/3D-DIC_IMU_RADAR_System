var a00123 =
[
    [ "inv_icm20948_augmented_init", "a00123.html#ga0e780fd57bb7c69b306090d04dc00ed9", null ],
    [ "inv_icm20948_augmented_sensors_get_gravity", "a00123.html#ga550f11cfd83d378fa5bc7aca1bd02957", null ],
    [ "inv_icm20948_augmented_sensors_get_linearacceleration", "a00123.html#ga63eac99c8a642716b60dcc51a5e8a6bb", null ],
    [ "inv_icm20948_augmented_sensors_get_orientation", "a00123.html#gaae887db8e8dc18856b2c3b82fb00bbbc", null ],
    [ "inv_icm20948_augmented_sensors_set_odr", "a00123.html#ga7e823c5c6b776cd85a3f149e7f4d4031", null ],
    [ "inv_icm20948_augmented_sensors_update_odr", "a00123.html#ga8f0e786aa15960902858b4dd0f061463", null ]
];