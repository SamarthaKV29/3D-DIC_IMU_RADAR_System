var a00124 =
[
    [ "inv_icm20948_compass_id", "a00124.html#gaad2a15491190d05a28d4b307afef44b9", [
      [ "INV_ICM20948_COMPASS_ID_NONE", "a00124.html#ggaad2a15491190d05a28d4b307afef44b9afa97e242c2c29b4168418ec2639a5bec", null ],
      [ "INV_ICM20948_COMPASS_ID_AK09911", "a00124.html#ggaad2a15491190d05a28d4b307afef44b9ae15987f8af80eeb000ce731afef2a72d", null ],
      [ "INV_ICM20948_COMPASS_ID_AK09912", "a00124.html#ggaad2a15491190d05a28d4b307afef44b9a6b4b85036c2d9e05c1e9b01a32eedb70", null ],
      [ "INV_ICM20948_COMPASS_ID_AK09916", "a00124.html#ggaad2a15491190d05a28d4b307afef44b9acf24364ac5e37b848c9ef9f29b51e968", null ],
      [ "INV_ICM20948_COMPASS_ID_AK08963", "a00124.html#ggaad2a15491190d05a28d4b307afef44b9a8489955279fc0fe84cee3a58c4e9b724", null ]
    ] ],
    [ "inv_icm20948_apply_raw_compass_matrix", "a00124.html#gab67473f6a0037d22a398bf674ac6b5e2", null ],
    [ "inv_icm20948_check_akm_self_test", "a00124.html#ga8a013e2382d33d54135ed2e5cae21fa3", null ],
    [ "inv_icm20948_compass_dmp_cal", "a00124.html#ga94241a93304d5ea4a7bacef12368ec4e", null ],
    [ "inv_icm20948_compass_getstate", "a00124.html#ga32bbd56babe9ec9073e1a24e00ceb15f", null ],
    [ "inv_icm20948_compass_isconnected", "a00124.html#ga08650a028a4d1bf89997c63e7af73ad2", null ],
    [ "inv_icm20948_read_akm_scale", "a00124.html#ga45631980f437339c8d2e8f15180c47a3", null ],
    [ "inv_icm20948_register_aux_compass", "a00124.html#ga30043b2465f4b7a6ca06168485aa58ae", null ],
    [ "inv_icm20948_resume_akm", "a00124.html#ga3556c8e6f4b00645bc3c6a4b14d5030a", null ],
    [ "inv_icm20948_setup_compass_akm", "a00124.html#ga790ecd92e7025e3e6877a93c248b934c", null ],
    [ "inv_icm20948_suspend_akm", "a00124.html#gacf83d9386446da612e87b6c751e25498", null ],
    [ "inv_icm20948_write_akm_scale", "a00124.html#ga7682eab99cc5f570ea91b686743a85aa", null ]
];