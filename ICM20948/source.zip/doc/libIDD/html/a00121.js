var a00121 =
[
    [ "INV_MAX_SERIAL_READ", "a00121.html#ga3239414549ba4d085a60637e40417cd9", null ],
    [ "INV_MAX_SERIAL_WRITE", "a00121.html#ga1a2ff08175c9aad83693b34f866960bc", null ],
    [ "inv_icm20648_read_mems", "a00121.html#gad9ec80c23e2f11dc4720e8e0dbb1758e", null ],
    [ "inv_icm20648_read_mems_reg", "a00121.html#ga1bca23f4dcbfee485ed3c7c6c7a61da6", null ],
    [ "inv_icm20648_write_mems", "a00121.html#ga7dc088725fb4268c7f6df61dac2f5ee2", null ],
    [ "inv_icm20648_write_mems_reg", "a00121.html#ga2a6faa6bad6bda295fb3c0737e4a56a5", null ],
    [ "inv_icm20648_write_single_mems_reg", "a00121.html#gaad71f72246c9a56e1f5578f418333fd9", null ],
    [ "inv_icm20648_write_single_mems_reg_core", "a00121.html#gafc2175ef32cfeca614f5dafbf759dd23", null ]
];