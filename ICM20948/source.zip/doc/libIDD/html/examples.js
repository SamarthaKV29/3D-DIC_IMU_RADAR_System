var examples =
[
    [ "ExampleDeviceIcm20648EMD.c", "a00005.html", null ],
    [ "ExampleDeviceIcm20948EMD.c", "a00007.html", null ],
    [ "ExampleSerifHal.c", "a00003.html", null ]
];