var searchData=
[
  ['supported_20devices',['Supported devices',['../a00009.html',1,'']]],
  ['sensor',['sensor',['../a00045.html#a2db958c515f20b172215bd75712f67ee',1,'inv_sensor_event']]],
  ['sensor_5ftype_5ficm20648',['sensor_type_icm20648',['../a00047.html',1,'']]],
  ['sensor_5ftype_5ficm20648_5ft',['sensor_type_icm20648_t',['../a00110.html#gae4411660ceec9e1088d061d94d3b482f',1,'Icm20648.h']]],
  ['sensor_5ftype_5ficm20948',['sensor_type_icm20948',['../a00048.html',1,'']]],
  ['sensor_5ftype_5ficm20948_5ft',['sensor_type_icm20948_t',['../a00122.html#ga1f9787115f4c829bf42c45e97f84cb49',1,'Icm20948.h']]],
  ['sensor_20configuration',['Sensor Configuration',['../a00101.html',1,'']]],
  ['sensor_20types',['Sensor types',['../a00100.html',1,'']]],
  ['serif_5ftype',['serif_type',['../a00023.html#a7bd156558b438b41f198333a0bad50d5',1,'inv_host_serif']]],
  ['size',['size',['../a00045.html#a55ca1b67e71b563a77d5a0f716cf8e95',1,'inv_sensor_event']]],
  ['sleep_5fefficiency',['sleep_efficiency',['../a00045.html#ad3dc68e694cfd6e80540c99185745729',1,'inv_sensor_event']]],
  ['sleep_5flatency',['sleep_latency',['../a00045.html#ad53437ef88930461bd5989e93ee14469',1,'inv_sensor_event']]],
  ['sleep_5fonset',['sleep_onset',['../a00045.html#aac6efed83568d5f3a8359b070af65268',1,'inv_sensor_event']]],
  ['sleep_5fphase',['sleep_phase',['../a00045.html#a2be4405b1a02d13a16a1a5b5e402f045',1,'inv_sensor_event']]],
  ['sleepanalysis',['sleepanalysis',['../a00045.html#a7c33a7569c826de4e50a2de52d3b498b',1,'inv_sensor_event']]],
  ['sqi',['sqi',['../a00045.html#a26ae9c9e8bc84c20d339fa212c53e792',1,'inv_sensor_event']]],
  ['status',['status',['../a00045.html#afce98c922be7d8f1b85dd7ad93a15f34',1,'inv_sensor_event::status()'],['../a00045.html#af7557ccc92293755ff7806f7893fe667',1,'inv_sensor_event::status()']]],
  ['step',['step',['../a00045.html#a94491bbdea417e7ec52f7c3b051ee6b9',1,'inv_sensor_event::step()'],['../a00045.html#a37da85080a2b4ef12d324e744c5211f2',1,'inv_sensor_event::step()']]],
  ['steprun',['stepRun',['../a00045.html#a4bdf7613b1364c6234e07058ad807422',1,'inv_sensor_event']]],
  ['stepwalk',['stepWalk',['../a00045.html#a40a71a665c9910907cad9541a2597bc9',1,'inv_sensor_event']]],
  ['suffix',['suffix',['../a00022.html#ab328ce4f9fdb2269bf006e06bd0d4ae7',1,'inv_fw_version']]]
];
