var searchData=
[
  ['supported_20devices',['Supported devices',['../a00009.html',1,'']]]
];
