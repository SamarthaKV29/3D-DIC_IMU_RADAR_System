var a00022 =
[
    [ "crc", "a00022.html#aa947865effe554754821583b049c11a1", null ],
    [ "patch", "a00022.html#a5a26acad6e8870b6f09d4562a2fe0ff3", null ],
    [ "suffix", "a00022.html#ab328ce4f9fdb2269bf006e06bd0d4ae7", null ]
];