var a00112 =
[
    [ "inv_icm20648_compass_id", "a00112.html#ga7d702cc5d78fa346434b94cfa15bddd6", [
      [ "INV_ICM20648_COMPASS_ID_NONE", "a00112.html#gga7d702cc5d78fa346434b94cfa15bddd6a2b794c0e5395c2b40a5c5b8e3611d1de", null ],
      [ "INV_ICM20648_COMPASS_ID_AK09911", "a00112.html#gga7d702cc5d78fa346434b94cfa15bddd6a4464fbe5b4486ba94e1d3315f3216934", null ],
      [ "INV_ICM20648_COMPASS_ID_AK09912", "a00112.html#gga7d702cc5d78fa346434b94cfa15bddd6a1a7fb105457704c32a369d51ddecf487", null ],
      [ "INV_ICM20648_COMPASS_ID_AK09916", "a00112.html#gga7d702cc5d78fa346434b94cfa15bddd6a28be84020e8aff6beb26ca27bb3b0ac6", null ],
      [ "INV_ICM20648_COMPASS_ID_AK08963", "a00112.html#gga7d702cc5d78fa346434b94cfa15bddd6aaf8b1c6c924f351709503739bbf8c466", null ]
    ] ],
    [ "inv_icm20648_apply_raw_compass_matrix", "a00112.html#ga012d77fd97754308f3603c1a91f8f143", null ],
    [ "inv_icm20648_check_akm_self_test", "a00112.html#gaeb69d17af59c5fc4c7c401f60b5005a2", null ],
    [ "inv_icm20648_compass_dmp_cal", "a00112.html#ga32d9bc9097a05e099f76de225b1315b1", null ],
    [ "inv_icm20648_compass_getstate", "a00112.html#ga2bc9586b5ff1319f9a554114f8658566", null ],
    [ "inv_icm20648_compass_isconnected", "a00112.html#ga5097ad08fc8fd801b262aae813aaad7d", null ],
    [ "inv_icm20648_read_akm_scale", "a00112.html#gadaa4913af472861b29b325f78beb1d41", null ],
    [ "inv_icm20648_register_aux_compass", "a00112.html#ga3bbd2d4f830366e98ef164bc3592b363", null ],
    [ "inv_icm20648_resume_akm", "a00112.html#ga2adb52116c11b497055ce9e8d74b39ce", null ],
    [ "inv_icm20648_setup_compass_akm", "a00112.html#gaa90dc7193b9c1fc2f16886012fb5c3d1", null ],
    [ "inv_icm20648_suspend_akm", "a00112.html#ga45dd7e7464ee7634c826f82e38e606bb", null ],
    [ "inv_icm20648_write_akm_scale", "a00112.html#ga36c29ba9d20ccf54543990d0d21acc1f", null ]
];