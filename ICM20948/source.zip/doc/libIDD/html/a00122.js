var a00122 =
[
    [ "Icm20948 driver serif", "a00131.html", "a00131" ],
    [ "Icm20948 driver setup", "a00132.html", "a00132" ],
    [ "Icm20948 driver transport", "a00133.html", "a00133" ],
    [ "sensor_type_icm20948", "a00048.html", null ],
    [ "inv_icm20948", "a00028.html", [
      [ "base_driver_t", "a00012.html", null ],
      [ "fifo_info_t", "a00013.html", null ],
      [ "inv_icm20948_secondary_states", "a00030.html", [
        [ "inv_icm20948_secondary_reg", "a00029.html", null ]
      ] ]
    ] ],
    [ "inv_icm20948_compass_state_t", "a00122.html#ga72b83718212779072d2c37ef7768f63f", null ],
    [ "sensor_type_icm20948_t", "a00122.html#ga1f9787115f4c829bf42c45e97f84cb49", null ],
    [ "inv_icm20948_compass_state", "a00122.html#gaa5cb0522a94c803eaa5729818bea9785", null ],
    [ "inv_icm20948_get_time_us", "a00122.html#ga6df2222ee8af28a8e0fc32828cbbc8f6", null ],
    [ "inv_icm20948_reset_states", "a00122.html#gaeecdee315a5045cb4d4f466621fef5ad", null ],
    [ "inv_icm20948_sleep_us", "a00122.html#gac72a1036c614f5913c7696342dde2b93", null ],
    [ "icm20948_instance", "a00122.html#gac6fb2f4bdaab7049c767d6724ad60267", null ]
];