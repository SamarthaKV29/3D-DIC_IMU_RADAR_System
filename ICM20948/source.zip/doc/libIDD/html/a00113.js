var a00113 =
[
    [ "COMPASS_I2C_SLV_READ", "a00113.html#ga94025fcc78d7b0214c9ea6cf978987a6", null ],
    [ "inv_icm20648_execute_read_secondary", "a00113.html#ga5fb6dd9fd935742500cf541d8ec156b7", null ],
    [ "inv_icm20648_execute_write_secondary", "a00113.html#gaf01572c3d6d77f80a3e7ad8d6120acd2", null ],
    [ "inv_icm20648_init_secondary", "a00113.html#ga6b0de650d2bbf4840eb221fe580428b7", null ],
    [ "inv_icm20648_read_secondary", "a00113.html#ga1d59b8009fc22aba4155fefa96014825", null ],
    [ "inv_icm20648_secondary_disable_i2c", "a00113.html#ga50e75461e8904bfee80a3ddb4bfd42ce", null ],
    [ "inv_icm20648_secondary_enable_i2c", "a00113.html#ga5b2d1b6aafefc0bf8bb9a29e2024e1f9", null ],
    [ "inv_icm20648_secondary_restoreI2cOdr", "a00113.html#ga04ef57d4bde10cbefb44910ad8f58e77", null ],
    [ "inv_icm20648_secondary_saveI2cOdr", "a00113.html#gaa8abf6f1b0660cfcac8def73c616acaa", null ],
    [ "inv_icm20648_secondary_set_odr", "a00113.html#ga8478dadb3d4848ff057457809ac98eea", null ],
    [ "inv_icm20648_secondary_stop_channel", "a00113.html#ga4f378a6b59f5650f3d4cc3810f45dc19", null ],
    [ "inv_icm20648_write_secondary", "a00113.html#ga23ec730570a87fc578551fe6ac180cd9", null ]
];