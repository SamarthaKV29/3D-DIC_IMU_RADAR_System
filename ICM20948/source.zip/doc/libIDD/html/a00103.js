var a00103 =
[
    [ "inv_device_emd_wrap_icm20xxx", "a00016.html", null ],
    [ "inv_device_emd_wrap_icm20xxx_serial", "a00017.html", null ],
    [ "inv_device_emd_wrap_icm20xxx_init", "a00103.html#gaf9f8717b6d52ea09b38752ff1351b4e1", null ]
];